#ifndef STACKHEADER_H
#define	STACKHEADER_H

#include <iostream>


using namespace std;

void PUSHI(int);
void PUSHM(int);
int POPM();
int STDOUT();
void STDIN(int);
void ADD();
void SUB();
void MUL();
void DIV();
void GRT();
void LES();
void EQU();

void NEQ();
void GEQ();
void LEQ();




#endif